Version 1.0 Release Candidate 1 (2014-06-23)
++++++++++++++++++++++++++++++++++++++++++++

This is the first public release.

Version 1.0 Release Candidate 2 (2014-07-14)
++++++++++++++++++++++++++++++++++++++++++++

- Added content-type='application/json' for requests with body

Version 1.0 Release Candidate 3 (2014-09-15)
++++++++++++++++++++++++++++++++++++++++++++

- Made content-type mandatory only when content is expected

Version 1.0 Release Candidate 4 (2015-02-18)
++++++++++++++++++++++++++++++++++++++++++++

- Allowed for extra details in error responses from Hubspot

Version 1.0 Release Candidate 5 (2016-03-18)
++++++++++++++++++++++++++++++++++++++++++++

- Added Python 3.4 and 3.5 compatibility by: @jtprince
